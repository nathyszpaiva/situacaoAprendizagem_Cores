// Classe principal que controla a lógica do jogo
class Game {
  constructor(optionsCount = 4) {
    this.optionsCount = optionsCount; // Número de opções de cores por rodada
    this.score = 0;                   // Pontuação do jogador
    this.round = 1;                   // Rodada atual
    this.colors = [];                 // Array com as cores da rodada
    this.correctColor = '';           // Cor correta que o jogador deve adivinhar
  }

  // Gera uma cor aleatória no formato hexadecimal
  generateRandomColor() {
    return '#' + Math.floor(Math.random() * 0xFFFFFF).toString(16).padStart(6, '0').toUpperCase();
  }

  // Inicia uma nova rodada: gera novas cores e escolhe uma como a correta
  startNewRound() {
    this.colors = Array.from({ length: this.optionsCount }, () => this.generateRandomColor());
    this.correctColor = this.colors[Math.floor(Math.random() * this.optionsCount)];
  }

  // Define a dificuldade alterando o número de opções (4, 6 ou 8)
  setDifficulty(level) {
    this.optionsCount = parseInt(level);
    this.round = 1;
    this.score = 0;
    this.startNewRound();
  }
}

// Cria uma instância do jogo
const game = new Game();

// Atalho para selecionar elementos do DOM por ID
const $ = (id) => document.getElementById(id);

// Seletores dos elementos interativos do HTML
const colorCodeDisplay = $('color-code');
const optionsContainer = $('options-container');
const feedback = $('feedback-message');
const score = $('score');
const round = $('round');
const resetBtn = $('reset-button');
const difficultySelect = $('difficulty'); // Novo seletor de dificuldade

// Atualiza a interface com as informações da rodada atual
function renderGame() {
  score.textContent = game.score;               // Atualiza a pontuação
  round.textContent = game.round;               // Atualiza a rodada
  colorCodeDisplay.textContent = game.correctColor; // Exibe o código da cor a ser adivinhada
  feedback.textContent = '';                    // Limpa o feedback anterior
  resetBtn.classList.remove('visible');         // Esconde o botão de próxima rodada

  // Limpa opções antigas e gera novas
  optionsContainer.innerHTML = '';
  game.colors.forEach(color => {
    const div = document.createElement('div'); // Cria div para cada cor
    div.className = 'color-option';            // Aplica classe para estilização
    div.style.backgroundColor = color;         // Define a cor de fundo
    div.dataset.color = color;                 // Armazena a cor como dado do elemento
    optionsContainer.appendChild(div);         // Adiciona à tela
  });
}

// Evento para quando o jogador clica em uma opção de cor
optionsContainer.addEventListener('click', ({ target }) => {
  if (!target.classList.contains('color-option')) return; // Ignora cliques fora das opções

  const isCorrect = target.dataset.color === game.correctColor; // Verifica se está correto
  feedback.textContent = isCorrect ? 'Correto!' : 'Incorreto!'; // Exibe mensagem apropriada

  if (isCorrect) {
    target.classList.add('correct'); // Marca visualmente como correta
    game.score++;                    // Incrementa pontuação
  } else {
    target.classList.add('wrong');   // Marca como errada
    // Mostra qual era a opção correta
    [...optionsContainer.children].forEach(div => {
      if (div.dataset.color === game.correctColor) {
        div.classList.add('correct');
      }
    });
  }

  // Impede novos cliques até a próxima rodada
  [...optionsContainer.children].forEach(div => div.style.pointerEvents = 'none');

  // Exibe o botão para próxima rodada
  resetBtn.classList.add('visible');
});

// Evento para iniciar a próxima rodada quando o botão for clicado
resetBtn.addEventListener('click', () => {
  game.round++;              // Avança para a próxima rodada
  game.startNewRound();      // Gera novas cores
  renderGame();              // Atualiza a interface
});

// Evento para trocar a dificuldade
difficultySelect.addEventListener('change', (event) => {
  const newLevel = event.target.value; // Valor do <select>
  game.setDifficulty(newLevel);        // Atualiza a dificuldade no jogo
  renderGame();                        // Atualiza a interface
});

// Inicializa o jogo assim que a página estiver carregada
window.addEventListener('DOMContentLoaded', () => {
  game.startNewRound(); // Primeira rodada
  renderGame();         // Mostra a interface inicial
});
